import React, { useState } from "react";

import { FaSearch, FaTimes } from "react-icons/fa";
import PurchaseOrderForm from '../../Components/PurchaseOrderForm'

const orders = [
  


{
    id: 12345,
    date: "2024-05-01",
    customer: "ABC Corp",
    status: "Shipped",
    amount: 500,
  },
  {
    id: 12346,
    date: "2024-05-02",
    customer: "XYZ Inc",
    status: "In Progress",
    amount: 1200,
  },
  {
    id: 12347,
    date: "2024-05-03",
    customer: "LMN Ltd",
    status: "Delivered",
    amount: 800,
  },
  {
    id: 12348,
    date: "2024-05-01",
    customer: "ABC Corp",
    status: "Shipped",
    amount: 500,
  },
  {
    id: 12349,
    date: "2024-05-02",
    customer: "XYZ Inc",
    status: "In Progress",
    amount: 1200,
  },
  {
    id: 12350,
    date: "2024-05-03",
    customer: "LMN Ltd",
    status: "Delivered",
    amount: 800,
  },
  {
    id: 12351,
    date: "2024-05-01",
    customer: "ABC Corp",
    status: "Shipped",
    amount: 500,
  },
  {
    id: 12352,
    date: "2024-05-02",
    customer: "XYZ Inc",
    status: "In Progress",
    amount: 1200,
  },
  {
    id: 12353,
    date: "2024-05-03",
    customer: "LMN Ltd",
    status: "Delivered",
    amount: 800,
  },
  {
    id: 12354,
    date: "2024-05-01",
    customer: "ABC Corp",
    status: "Shipped",
    amount: 500,
  },
  {
    id: 12356,
    date: "2024-05-02",
    customer: "XYZ Inc",
    status: "In Progress",
    amount: 1200,
  },
  {
    id: 12357,
    date: "2024-05-03",
    customer: "LMN Ltd",
    status: "Delivered",
    amount: 800,
  },
];

const OrderTracking = () => {
  const [filterStatus, setFilterStatus] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [showPurchaseOrderModal, setShowPurchaseOrderModal] = useState(false); // State for PurchaseOrderForm modal
  const ordersPerPage = 10;

  const filteredOrders = orders.filter((order) => {
    const queryMatch = searchQuery
      ? order.id.toString().includes(searchQuery) ||
        order.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.status.toLowerCase().includes(searchQuery.toLowerCase())
      : true;

    const statusMatch = filterStatus ? order.status === filterStatus : true;
    const dateMatch = filterDate ? order.date === filterDate : true;

    return queryMatch && statusMatch && dateMatch;
  });

  const indexOfLastOrder = currentPage * ordersPerPage;
  const indexOfFirstOrder = indexOfLastOrder - ordersPerPage;
  const currentOrders = filteredOrders.slice(indexOfFirstOrder, indexOfLastOrder);
  const totalPages = Math.ceil(filteredOrders.length / ordersPerPage);

  return (
    <div className="p-4">
      <div className="flex space-x-4 mb-4">
        <select
          className="border p-2"
          value={filterStatus}
          onChange={(e) => {
            setFilterStatus(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="">Filter by Status</option>
          <option value="Shipped">Shipped</option>
          <option value="In Progress">In Progress</option>
          <option value="Delivered">Delivered</option>
        </select>
        <input
          type="date"
          className="border p-2"
          value={filterDate}
          onChange={(e) => {
            setFilterDate(e.target.value);
            setCurrentPage(1);
          }}
        />
        <div className="relative">
          <input
            type="text"
            className="border p-2 pl-10"
            placeholder="Search Orders"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
          <FaSearch className="absolute left-3 top-3 text-gray-500" />
        </div>
        <button
          className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600"
          onClick={() => setShowPurchaseOrderModal(true)} // Open PurchaseOrderForm modal
        >
          Create New Order
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full border-collapse border border-gray-200">
          <thead>
            <tr>
              <th className="border border-gray-300 px-4 py-2">Order ID</th>
              <th className="border border-gray-300 px-4 py-2">Order Date</th>
              <th className="border border-gray-300 px-4 py-2">Customer</th>
              <th className="border border-gray-300 px-4 py-2">Status</th>
              <th className="border border-gray-300 px-4 py-2">Amount</th>
              <th className="border border-gray-300 px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentOrders.map((order) => (
              <tr key={order.id}>
                <td className="border border-gray-300 px-4 py-2">{order.id}</td>
                <td className="border border-gray-300 px-4 py-2">{order.date}</td>
                <td className="border border-gray-300 px-4 py-2">{order.customer}</td>
                <td className="border border-gray-300 px-4 py-2">{order.status}</td>
                <td className="border border-gray-300 px-4 py-2">${order.amount}</td>
                <td className="border border-gray-300 px-4 py-2">
                  <button
                    className="bg-blue-500 text-white px-4 py-2"
                    onClick={() => setSelectedOrder(order)}
                  >
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex justify-center mt-4">
        {totalPages > 1 && (
          <div className="space-x-2">
            {Array.from({ length: totalPages }, (_, index) => (
              <button
                key={index}
                className={`px-4 py-2 ${currentPage === index + 1 ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700"}`}
                onClick={() => setCurrentPage(index + 1)}
              >
                {index + 1}
              </button>
            ))}
          </div>
        )}
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/2 relative">
            <FaTimes
              className="absolute top-3 right-3 cursor-pointer text-gray-500 hover:text-red-500"
              size={24}
              onClick={() => setSelectedOrder(null)}
            />
            <h2 className="text-2xl mb-4">Order Details</h2>
            <p><strong>Order ID:</strong> {selectedOrder.id}</p>
            <p><strong>Order Date:</strong> {selectedOrder.date}</p>
            <p><strong>Customer:</strong> {selectedOrder.customer}</p>
            <p><strong>Status:</strong> {selectedOrder.status}</p>
            <p><strong>Amount:</strong> ${selectedOrder.amount}</p>
          </div>
        </div>
      )}

      {showPurchaseOrderModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/2 relative">
            <FaTimes
              className="absolute top-3 right-3 cursor-pointer text-gray-500 hover:text-red-500"
              size={24}
              onClick={() => setShowPurchaseOrderModal(false)}
            />
            <PurchaseOrderForm />
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderTracking;
