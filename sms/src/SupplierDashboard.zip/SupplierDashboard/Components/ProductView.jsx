import React from 'react';
import { FaTimes } from 'react-icons/fa';

const ProductView = ({ product, onClose }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50">
      <div className="bg-white p-6 rounded w-full max-w-lg">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl">Product Details</h2>
          <button onClick={onClose}>
            <FaTimes />
          </button>
        </div>
        <div className="mb-4">
          <strong>Product Name:</strong> {product.productName}
        </div>
        <div className="mb-4">
          <strong>Quantity:</strong> {product.quantityAvailable}
        </div>
        <div className="mb-4">
          <strong>Unit Price:</strong> ${product.unitPrice}
        </div>
        <div className="mb-4">
          <strong>Specification:</strong> {product.description}
        </div>
        <div className="mb-4">
          <strong>Image:</strong> <img src={URL.createObjectURL(product.images)} alt={product.productName} />
        </div>
      </div>
    </div>
  );
};

export default ProductView;
