import React, { useState } from "react";
import {
  HomeIcon,
  CubeIcon,
  ClipboardListIcon,
  DocumentTextIcon,
  CurrencyDollarIcon,
  ChatIcon,
  CogIcon,
  MenuIcon,
  XIcon,
} from "@heroicons/react/outline";


const Sidebar = ({ setActiveComponent }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleSectionClick = (section) => {
    setActiveComponent(section);
    setActiveSection(section);
  };

  const handleSettingsClick = () => {
    handleSectionClick("profile");
  };

  const renderButton = (section, Icon, label) => (
    <button
      onClick={() => handleSectionClick(section)}
      className={`flex items-center p-2 space-x-1 rounded-md hover:bg-gray-700 transition-colors duration-300
        ${
          activeSection === section
            ? "bg-gray-900 text-white border-l-4 border-blue-500"
            : "text-gray-400"
        }`}
    >
      <Icon className="w-6 h-6" />
      <span className={`text-base ${!isOpen && "hidden"}`}>{label}</span>
    </button>
  );

  return (
    <div
      className={`flex flex-col h-full p-3 bg-gray-800 text-white transition-all duration-300 ${
        isOpen ? "w-full md:w-64" : "w-20"
      }`}
    >
      <div className="flex items-center justify-between">
        <h1
          className={`text-lg font-bold transition-all duration-300 ${
            !isOpen && "hidden"
          }`}
        >
          Supplier
        </h1>
        <button
          onClick={toggleSidebar}
          className="p-1 rounded-md focus:outline-none focus:ring"
        >
          {isOpen ? <XIcon className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
        </button>
      </div>
      <div className="flex flex-col mt-6 space-y-4 overflow-auto">
        {renderButton("home", HomeIcon, "Home")}
        {renderButton("dashboard", ClipboardListIcon, "Dashboard")}
        {renderButton("goods-and-materials", CubeIcon, "Goods and Materials")}
        {renderButton("stock-management", DocumentTextIcon, "StockManagement")}
        {renderButton("order", ClipboardListIcon, "Order")}
        {renderButton("payments", CurrencyDollarIcon, "Payments")}
        {renderButton("communication", ChatIcon, "Communication")}
      </div>
      <div className="mt-auto">
        <button
          onClick={handleSettingsClick}
          className={`flex items-center p-2 space-x-2 rounded-md hover:bg-gray-700 transition-colors duration-300
            ${
              activeSection === "profile"
                ? "bg-gray-900 text-white border-l-4 border-blue-500"
                : "text-gray-400"
            }`}
        >
          <CogIcon className="w-6 h-6" />
          <span className={`text-base ${!isOpen && "hidden"}`}>Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
