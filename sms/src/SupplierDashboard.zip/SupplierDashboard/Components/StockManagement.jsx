import React, { useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import { PlusIcon, SearchIcon, XIcon } from '@heroicons/react/solid';

const StockManagement = () => {
  const [items, setItems] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [form, setForm] = useState({
    id: '',
    productName: '',
    quantity: 0,
    unitPrice: 0,
    totalAmount: 0,
    orderDate: '',
    deliveryDate: '',
    customerName: '',
    deliveryAddress: '',
    status: 'pending',
  });
  const [searchTerm, setSearchTerm] = useState('');

  const openModal = () => setIsOpen(true);
  const closeModal = () => setIsOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prevForm) => {
      const updatedForm = {
        ...prevForm,
        [name]: value,
      };
      if (name === 'quantity' || name === 'unitPrice') {
        updatedForm.totalAmount = updatedForm.quantity * updatedForm.unitPrice;
      }
      return updatedForm;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setItems([...items, { ...form, id: Date.now().toString() }]);
    setForm({
      id: '',
      productName: '',
      quantity: 0,
      unitPrice: 0,
      totalAmount: 0,
      orderDate: '',
      deliveryDate: '',
      customerName: '',
      deliveryAddress: '',
      status: 'pending',
    });
    closeModal();
  };

  const filteredItems = items.filter((item) =>
    item.productName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row justify-between items-center mb-4">
        <button
          onClick={openModal}
          className="bg-blue-500 text-white px-4 py-2 rounded-md flex items-center mb-2 md:mb-0"
        >
          <PlusIcon className="h-5 w-5 mr-2" />
          Create New Item
        </button>
        {filteredItems.length > 0 && (
          <div className="relative w-full md:w-auto">
            <input
              type="text"
              placeholder="Search by product name"
              className="w-full md:w-64 border border-gray-300 rounded-md p-2 pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <SearchIcon className="h-5 w-5 absolute right-2 top-2 text-gray-500" />
          </div>
        )}
      </div>
      {filteredItems.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-200">
            <thead>
              <tr>
                <th className="border px-4 py-2">ID</th>
                <th className="border px-4 py-2">Product Name</th>
                <th className="border px-4 py-2">Quantity</th>
                <th className="border px-4 py-2">Unit Price</th>
                <th className="border px-4 py-2">Total Amount</th>
                <th className="border px-4 py-2">Delivery Date</th>
                <th className="border px-4 py-2">Status</th>
                <th className="border px-4 py-2">Shipping Address</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item) => (
                <tr key={item.id}>
                  <td className="border px-4 py-2">{item.id}</td>
                  <td className="border px-4 py-2">{item.productName}</td>
                  <td className="border px-4 py-2">{item.quantity}</td>
                  <td className="border px-4 py-2">{item.unitPrice}</td>
                  <td className="border px-4 py-2">{item.totalAmount}</td>
                  <td className="border px-4 py-2">{item.deliveryDate}</td>
                  <td className="border px-4 py-2">
                    <select
                      className="border-none bg-transparent"
                      value={item.status}
                      onChange={(e) => {
                        const newStatus = e.target.value;
                        setItems((prevItems) =>
                          prevItems.map((i) =>
                            i.id === item.id ? { ...i, status: newStatus } : i
                          )
                        );
                      }}
                    >
                      <option value="shipped">Shipped</option>
                      <option value="progress">In Progress</option>
                      <option value="fulfilled">Fulfilled</option>
                    </select>
                  </td>
                  <td className="border px-4 py-2">{item.deliveryAddress}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Transition appear show={isOpen} as={Fragment}>
        <Dialog as="div" className="relative z-10" onClose={closeModal}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0 scale-95"
            enterTo="opacity-100 scale-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100 scale-100"
            leaveTo="opacity-0 scale-95"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-lg transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title
                    as="div"
                    className="flex justify-between items-center"
                  >
                    <h3 className="text-lg font-medium leading-6 text-gray-900">
                      Create New Stock Item
                    </h3>
                    <button onClick={closeModal}>
                      <XIcon className="h-5 w-5 text-gray-500" />
                    </button>
                  </Dialog.Title>
                  <div className="mt-2">
                    <form onSubmit={handleSubmit}>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="col-span-1">
                          <label className="block text-sm font-medium text-gray-700">
                            Order Date
                          </label>
                          <input
                            type="date"
                            name="orderDate"
                            value={form.orderDate}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-1">
                          <label className="block text-sm font-medium text-gray-700">
                            Delivery Date
                          </label>
                          <input
                            type="date"
                            name="deliveryDate"
                            value={form.deliveryDate}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Product Name
                          </label>
                          <input
                            type="text"
                            name="productName"
                            value={form.productName}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-1">
                          <label className="block text-sm font-medium text-gray-700">
                            Quantity
                          </label>
                          <input
                            type="number"
                            name="quantity"
                            value={form.quantity}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-1">
                          <label className="block text-sm font-medium text-gray-700">
                            Unit Price
                          </label>
                          <input
                            type="number"
                            name="unitPrice"
                            value={form.unitPrice}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Total Amount
                          </label>
                          <input
                            type="number"
                            name="totalAmount"
                            value={form.totalAmount}
                            readOnly
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md bg-gray-100"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Customer Name
                          </label>
                          <input
                            type="text"
                            name="customerName"
                            value={form.customerName}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Delivery Address
                          </label>
                          <input
                            type="text"
                            name="deliveryAddress"
                            value={form.deliveryAddress}
                            onChange={handleChange}
                            required
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-medium text-gray-700">
                            Status
                          </label>
                          <select
                            name="status"
                            value={form.status}
                            onChange={handleChange}
                            className="mt-1 p-2 block w-full border border-gray-300 rounded-md"
                          >
                            <option value="pending">Pending</option>
                            <option value="shipped">Shipped</option>
                            <option value="progress">In Progress</option>
                            <option value="fulfilled">Fulfilled</option>
                          </select>
                        </div>
                      </div>
                      <div className="mt-4">
                        <button
                          type="submit"
                          className="inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-medium text-white hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                        >
                          Save
                        </button>
                      </div>
                    </form>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </div>
  );
};

export default StockManagement;
